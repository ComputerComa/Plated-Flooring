require("prototypes.tile.tiles")
require("prototypes.item.tiles")
require("prototypes.recipe.tiles")